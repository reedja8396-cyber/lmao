# Advanced Discord Bot

Full-featured moderation bot with tickets, jail, giveaways, music, etc.

## Setup
1. `pip install -r requirements.txt`
2. Create `.env` with `DISCORD_TOKEN=your_token`
3. Run `python bot.py`

For Music: Run a Lavalink server and add credentials to .env
